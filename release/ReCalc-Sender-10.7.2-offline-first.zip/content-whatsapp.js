const PENDING_DRAFT_KEY = "recalc.pendingWhatsAppDraft";
const DEFAULT_SELECTOR_PACK = {
  selectors: {
    messageInput:
      "footer div[contenteditable='true'][role='textbox'], footer div[contenteditable='true'], div[role='textbox'][contenteditable='true'][aria-label='Escribir un mensaje'], div[role='textbox'][contenteditable='true'][aria-label='Write a message']",

    sendButton:
      "button[aria-label='Enviar'], button[aria-label='Send'], div[role='button'][aria-label='Enviar'], div[role='button'][aria-label='Send'], div[role='button'][aria-label*='Send'][aria-label*='selected'], div[role='button'][aria-label*='Enviar'][aria-label*='seleccionado'], span[data-icon='wds-ic-send-filled'], span[data-testid='wds-ic-send-filled'], span[data-icon='send-filled'], span[data-icon='send']",

    attachButton:
      "button[aria-label='Adjuntar'], button[aria-label='Attach'], [role='button'][aria-label='Adjuntar'], [role='button'][aria-label='Attach'], button[aria-label*='Adjuntar'], button[aria-label*='Attach'], [role='button'][aria-label*='Adjuntar'], [role='button'][aria-label*='Attach'], button[title*='Adjuntar'], button[title*='Attach'], span[data-testid='plus-rounded'], span[data-icon='plus-rounded'], span[data-icon='plus']",

    fileInput:
      "input[type='file'][accept*='image'], input[type='file'][accept*='video'], input[type='file']",

    mediaCaptionInput:
      "div[contenteditable='true'][role='textbox'][aria-label*='Escribir un mensaje para'], div[contenteditable='true'][role='textbox'][aria-label*='Write a message for'], div[contenteditable='true'][role='textbox'][data-tab='10'], div[contenteditable='true'][role='textbox'][data-tab='6'], p.copyable-text",

    conversationReady:
      "header, div[data-testid='conversation-panel-wrapper'], main[role='main']",
  },
};

let awaitingChatNotified = false;
let observer = null;
let applyingDraft = false;

function mergeSelector(defaultSelector, overrideSelector) {
  const pieces = [
    String(overrideSelector || "").trim(),
    String(defaultSelector || "").trim(),
  ].filter(Boolean);

  return pieces
    .join(", ")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean)
    .filter((item, index, list) => list.indexOf(item) === index)
    .join(", ");
}

function normalizeSelectorPack(pack) {
  const selectors =
    pack && typeof pack === "object" && typeof pack.selectors === "object"
      ? pack.selectors
      : {};

  return {
    selectors: {
      messageInput:
        mergeSelector(
          DEFAULT_SELECTOR_PACK.selectors.messageInput,
          typeof selectors.messageInput === "string" ? selectors.messageInput : "",
        ),

      sendButton:
        mergeSelector(
          DEFAULT_SELECTOR_PACK.selectors.sendButton,
          typeof selectors.sendButton === "string" ? selectors.sendButton : "",
        ),

      attachButton:
        mergeSelector(
          DEFAULT_SELECTOR_PACK.selectors.attachButton,
          typeof selectors.attachButton === "string" ? selectors.attachButton : "",
        ),

      fileInput:
        mergeSelector(
          DEFAULT_SELECTOR_PACK.selectors.fileInput,
          typeof selectors.fileInput === "string" ? selectors.fileInput : "",
        ),

      mediaCaptionInput:
        mergeSelector(
          DEFAULT_SELECTOR_PACK.selectors.mediaCaptionInput,
          typeof selectors.mediaCaptionInput === "string" ? selectors.mediaCaptionInput : "",
        ),

      conversationReady:
        mergeSelector(
          DEFAULT_SELECTOR_PACK.selectors.conversationReady,
          typeof selectors.conversationReady === "string" ? selectors.conversationReady : "",
        ),
    },
  };
}
function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function parseSelectorList(rawSelectors) {
  return String(rawSelectors ?? "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

function isVisible(element) {
  if (!element) return false;
  const style = window.getComputedStyle(element);
  const rect = element.getBoundingClientRect();
  return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
}

function findFirstVisible(selectors) {
  for (const selector of parseSelectorList(selectors)) {
    const nodes = Array.from(document.querySelectorAll(selector));
    const visible = nodes.find((node) => isVisible(node));
    if (visible) return visible;
    if (nodes[0]) return nodes[0];
  }
  return null;
}

function findComposer(selectorPack) {
  const selectors = normalizeSelectorPack(selectorPack).selectors.messageInput;
  const footer = document.querySelector("footer");
  if (footer) {
    for (const selector of parseSelectorList(selectors)) {
      const nodes = Array.from(footer.querySelectorAll(selector));
      const visible = nodes.find((node) => isVisible(node));
      if (visible) return visible;
      if (nodes[0]) return nodes[0];
    }
  }
  return findFirstVisible(selectors);
}

function findSendButton(selectorPack) {
  const selectors = normalizeSelectorPack(selectorPack).selectors.sendButton;
  const footer = document.querySelector("footer");

  if (footer) {
    for (const selector of parseSelectorList(selectors)) {
      let nodes = [];

      try {
        nodes = Array.from(footer.querySelectorAll(selector));
      } catch {
        continue;
      }

      const visible = nodes.find((node) => isVisible(node));
      if (visible) {
        return visible.closest?.("button, [role='button']") || visible;
      }

      if (nodes[0]) {
        return nodes[0].closest?.("button, [role='button']") || nodes[0];
      }
    }
  }

  const fromSelectors = findFirstVisible(selectors);

  if (fromSelectors) {
    return fromSelectors.closest?.("button, [role='button']") || fromSelectors;
  }

  const candidates = Array.from(document.querySelectorAll("button, [role='button']"))
    .filter((node) => isVisible(node))
    .filter((node) => {
      const icon = node.querySelector(
        "[data-icon='wds-ic-send-filled'], [data-testid='wds-ic-send-filled'], [data-icon='send-filled'], [data-icon='send']",
      );

      const label = String(
        node.getAttribute("aria-label") ||
          node.getAttribute("title") ||
          node.textContent ||
          "",
      ).toLowerCase();

      return (
        icon ||
        label === "send" ||
        label === "enviar" ||
        (label.includes("send") && label.includes("selected")) ||
        (label.includes("enviar") && label.includes("seleccion"))
      );
    });

  return candidates[0] || null;
}

function findAttachButton(selectorPack) {
  const fromSelectors = findFirstVisible(
    normalizeSelectorPack(selectorPack).selectors.attachButton,
  );

  if (fromSelectors) {
    const clickable =
      fromSelectors.closest?.("button, [role='button']") ||
      fromSelectors;

    if (clickable instanceof Element && isVisible(clickable)) {
      return clickable;
    }
  }

  const candidates = Array.from(
    document.querySelectorAll("button, [role='button']"),
  )
    .filter((node) => isVisible(node))
    .filter((node) => {
      const icon = node.querySelector(
        "[data-icon='plus-rounded'], [data-testid='plus-rounded'], [data-icon='plus']",
      );

      const label = String(
        node.getAttribute("aria-label") ||
          node.getAttribute("title") ||
          node.textContent ||
          "",
      ).toLowerCase();

      return (
        icon ||
        label.includes("adjuntar") ||
        label.includes("attach")
      );
    });

  return candidates[0] || null;
}

function findFileInput(selectorPack) {
  const selectors = normalizeSelectorPack(selectorPack).selectors;
  const candidates = [];
  for (const selector of parseSelectorList(selectors.fileInput)) {
    const nodes = Array.from(document.querySelectorAll(selector));
    for (const node of nodes) {
      if (node instanceof HTMLInputElement && node.type === "file" && !node.disabled) {
        candidates.push(node);
      }
    }
  }

  const uniqueCandidates = candidates.filter((node, index, list) => list.indexOf(node) === index);
  const scoreInput = (input) => {
    const accept = String(input.accept || "").toLowerCase();
    const multiple = Boolean(input.multiple);
    let score = 0;
    if (accept.includes("image")) score += 3;
    if (accept.includes("video")) score += 6;
    if (multiple) score += 4;
    if (accept.includes("audio")) score -= 4;
    if (accept === "image/*" && !multiple) score -= 6;
    return score;
  };

  return uniqueCandidates
    .map((input) => ({ input, score: scoreInput(input) }))
    .sort((a, b) => b.score - a.score)[0]?.input || null;
}

function findCaptionComposer(selectorPack) {
  return findFirstVisible(normalizeSelectorPack(selectorPack).selectors.mediaCaptionInput);
}

function findConversationReady(selectorPack) {
  return findFirstVisible(normalizeSelectorPack(selectorPack).selectors.conversationReady);
}

function readComposerText(composer) {
  return String(composer?.innerText ?? composer?.textContent ?? "")
    .replace(/\u00a0/g, " ")
    .replace(/\r\n?/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function setComposerSelection(composer, collapseToEnd = true) {
  if (!(composer instanceof Element)) return;
  const selection = window.getSelection();
  const range = document.createRange();
  range.selectNodeContents(composer);
  range.collapse(collapseToEnd);
  selection?.removeAllRanges();
  selection?.addRange(range);
}

function buildComposerHtml(text, lexicalMode) {
  const lines = String(text || "").split("\n");
  if (!lexicalMode) {
    return lines.map((line) => escapeHtml(line)).join("<br>");
  }

  return lines
    .map((line) =>
      line
        ? `<p dir="ltr"><span data-lexical-text="true">${escapeHtml(line)}</span></p>`
        : '<p dir="ltr"><br></p>',
    )
    .join("");
}

function normalizeComposerText(value) {
  return String(value ?? "")
    .replace(/\u00a0/g, " ")
    .replace(/\r\n?/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function fillLexicalComposer(composer, normalized) {
  const editor = composer?.__lexicalEditor;
  if (!editor || typeof editor.update !== "function") return false;

  const ParagraphNode =
    editor._nodes?.get?.("bidi-paragraph")?.klass ||
    editor._nodes?.get?.("paragraph")?.klass;
  const TextNode = editor._nodes?.get?.("text")?.klass;
  const LineBreakNode = editor._nodes?.get?.("linebreak")?.klass;

  if (!ParagraphNode || !TextNode) return false;

  let applied = false;
  editor.update(() => {
    const root = editor.getEditorState()?._nodeMap?.get?.("root")?.getWritable?.();
    if (!root) return;

    root.clear();
    const paragraph = new ParagraphNode();
    const lines = normalized.split("\n");

    lines.forEach((line, index) => {
      if (line) {
        paragraph.append(new TextNode(line));
      }
      if (index < lines.length - 1 && LineBreakNode) {
        paragraph.append(new LineBreakNode());
      }
    });

    if (!paragraph.getChildrenSize?.()) {
      paragraph.append(new TextNode(""));
    }

    root.append(paragraph);
    paragraph.selectEnd();
    applied = true;
  }, { discrete: true });

  if (!applied) return false;
  let currentText = "";
  editor.getEditorState().read(() => {
    currentText = normalizeComposerText(
      editor.getEditorState()?._nodeMap?.get?.("root")?.getTextContent?.() || "",
    );
  });
  return currentText === normalized;
}

function clearComposer(composer) {
  if (!(composer instanceof Element)) return;
  const selection = window.getSelection();
  const range = document.createRange();
  range.selectNodeContents(composer);
  selection?.removeAllRanges();
  selection?.addRange(range);
  try {
    document.execCommand("delete");
  } catch {
    // fallback below
  }
  composer.textContent = "";
  composer.innerHTML = "";
  composer.dispatchEvent(
    new InputEvent("input", {
      bubbles: true,
      inputType: "deleteContentBackward",
      data: null,
    }),
  );
  composer.dispatchEvent(new Event("change", { bubbles: true }));
  setComposerSelection(composer, true);
}

function resolveClickable(target) {
  if (!(target instanceof Element)) return null;
  return (
    target.closest?.("button, [role='button'], [role='menuitem']") ||
    (target.matches?.("button, [role='button'], [role='menuitem']") ? target : null)
  );
}

function clickElement(target) {
  const clickable = resolveClickable(target);
  if (!(clickable instanceof HTMLElement)) return false;

  clickable.scrollIntoView?.({ block: "center", inline: "center" });
  clickable.focus?.();
  ["pointerdown", "mousedown", "pointerup", "mouseup"].forEach((eventName) => {
    clickable.dispatchEvent(new MouseEvent(eventName, {
      bubbles: true,
      cancelable: true,
      composed: true,
    }));
  });
  clickable.click();
  return true;
}

function fillComposer(composer, draftText) {
  const normalized = normalizeComposerText(draftText);
  if (!normalized || !composer) return false;

  if (readComposerText(composer) === normalized) return true;

  if (composer.getAttribute("data-lexical-editor") === "true") {
    return fillLexicalComposer(composer, normalized);
  }

  composer.focus();
  clearComposer(composer);
  setComposerSelection(composer, true);

  let inserted = false;
  try {
    inserted = document.execCommand("insertText", false, normalized);
  } catch {
    inserted = false;
  }

  if (!inserted || readComposerText(composer) !== normalized) {
    const lexicalMode = composer.getAttribute("data-lexical-editor") === "true";
    composer.innerHTML = buildComposerHtml(normalized, lexicalMode);
  }

  composer.dispatchEvent(
    new InputEvent("input", {
      bubbles: true,
      inputType: "insertText",
      data: normalized,
    }),
  );
  composer.dispatchEvent(new Event("change", { bubbles: true }));

  if (readComposerText(composer) !== normalized) {
    composer.textContent = normalized;
    composer.dispatchEvent(
      new InputEvent("input", {
        bubbles: true,
        inputType: "insertText",
        data: normalized,
      }),
    );
    composer.dispatchEvent(new Event("change", { bubbles: true }));
  }
  return readComposerText(composer) === normalized;
}

function clickSend(selectorPack) {
  const button = findSendButton(selectorPack);
  if (!button) return false;
  return clickElement(button);
}

function wait(ms) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

async function waitFor(fn, timeoutMs = 12000, intervalMs = 250) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const result = fn();
    if (result) return result;
    await wait(intervalMs);
  }
  return null;
}

function assignFilesToInput(input, files) {
  const dataTransfer = new DataTransfer();
  files.forEach((file) => dataTransfer.items.add(file));
  input.files = dataTransfer.files;
  input.dispatchEvent(new Event("change", { bubbles: true }));
  input.dispatchEvent(new Event("input", { bubbles: true }));
}

async function fetchMediaFile(url, extensionSessionToken) {
  const headers = new Headers();
  const token = String(extensionSessionToken ?? "").trim();
  if (token) {
    headers.set("Authorization", `Bearer ${token}`);
    headers.set("x-extension-session-token", token);
  }

  const response = await fetch(url, {
    method: "GET",
    headers,
    credentials: "include",
    cache: "no-store",
  });

  if (!response.ok) {
    throw new Error("No fue posible descargar la imagen de la campaña.");
  }

  const blob = await response.blob();
  const contentType = blob.type || response.headers.get("content-type") || "application/octet-stream";
  const extension =
    contentType.includes("png")
      ? "png"
      : contentType.includes("webp")
        ? "webp"
        : contentType.includes("gif")
          ? "gif"
          : contentType.includes("mp4")
            ? "mp4"
            : contentType.includes("webm")
              ? "webm"
              : "jpg";

  return new File([blob], `campaign-media.${extension}`, { type: contentType });
}

async function attachMedia(selectorPack, mediaUrl, extensionSessionToken) {
  if (!mediaUrl) return false;

  const attachButton = findAttachButton(selectorPack);
  if (!clickElement(attachButton)) {
    throw new Error("No fue posible abrir el menú de adjuntos en WhatsApp Web.");
  }
  // Aumentar el tiempo de espera después de abrir el menú para
  // garantizar que la animación termine antes de buscar las opciones.
  await wait(500);

  const menuOptions = await waitFor(
    () =>
      Array.from(
        document.querySelectorAll("[role='menuitem'], [data-animate-dropdown-item='true']"),
      ).filter((node) => isVisible(node)),
    6000,
    200,
  );
  /*
   * WhatsApp Web ha cambiado el orden de las opciones del menú de adjuntos en
   * distintas versiones. Anteriormente se asumía que la opción de "Fotos y
   * videos" se encontraba en la segunda posición (índice 1), pero esto ya no
   * siempre es cierto. Para evitar seleccionar una opción incorrecta (por
   * ejemplo "Documento" o "Sticker"), buscamos primero por palabras
   * clave en la etiqueta o el texto visible del elemento. Si no se
   * encuentra ninguna coincidencia, usamos como último recurso la opción
   * existente en la posición 1 o 0.
   */
  let mediaOption = null;
  if (Array.isArray(menuOptions) && menuOptions.length) {
    const needles = [
      "photos & videos",
      "photos and videos",
      "fotos y videos",
      "photos",
      "videos",
      "fotos",
    ];
    mediaOption =
      menuOptions.find((node) => {
        const pieces = [
          node?.getAttribute?.("aria-label"),
          node?.getAttribute?.("title"),
          node?.textContent,
          node?.innerText,
        ];
        const haystack = pieces
          .map((v) => String(v || "").trim().toLowerCase())
          .filter(Boolean)
          .join(" ");
        return needles.some((needle) => haystack.includes(needle.toLowerCase()));
      }) || null;
    if (!mediaOption) {
      mediaOption = null;
    }
  }
  if (mediaOption) {
    const optionText = [mediaOption.getAttribute?.("aria-label"), mediaOption.getAttribute?.("title"), mediaOption.textContent]
      .map((value) => String(value || "").toLowerCase()).join(" ");
    if (/sticker|pegatina|calcoman/i.test(optionText)) {
      throw new Error("Se bloqueó una opción de Sticker; el archivo no se enviará.");
    }
  }
  if (!clickElement(mediaOption)) {
    throw new Error("No fue posible seleccionar Fotos y videos en WhatsApp Web.");
  }
  // Dar más tiempo para que el input de archivos se inserte luego de
  // seleccionar la opción correcta. En algunos casos el input tarda
  // más de 300 ms en aparecer.
  await wait(500);

  const fileInput = await waitFor(() => findFileInput(selectorPack), 10000, 300);
  if (fileInput instanceof HTMLInputElement) {
    const accept = String(fileInput.accept || "").toLowerCase().trim();
    const safeMediaInput = accept.includes("video") || (fileInput.multiple && accept.includes("image"));
    if (!safeMediaInput || (accept === "image/*" && !fileInput.multiple)) {
      throw new Error("El input detectado puede corresponder a Sticker y fue bloqueado.");
    }
  }
  if (!(fileInput instanceof HTMLInputElement)) {
    throw new Error("No fue posible encontrar el input de adjuntos en WhatsApp Web.");
  }

  const file = await fetchMediaFile(mediaUrl, extensionSessionToken);
  assignFilesToInput(fileInput, [file]);
  const preview = await waitFor(
    () =>
      document.querySelector(
        "div[role='dialog'], div[data-testid='media-viewer'], div[data-animate-modal-body='true']",
      ),
    // Extender el timeout a 15 s para detectar el modal de preview, ya que
    // algunos usuarios experimentan retrasos en su aparición.
    15000,
    250,
  );
  if (!preview) {
    throw new Error("No se detectó un preview válido para la imagen en WhatsApp Web.");
  }

  // Dar más tiempo antes de continuar una vez que el preview está
  // disponible, permitiendo al usuario ver el adjunto y a la página
  // estabilizarse.
  await wait(2000);
  return true;
}

function detectInvalidPhoneMessage() {
  const bodyText = document.body?.innerText?.toLowerCase?.() || "";
  const patterns = [
    "phone number shared via url is invalid",
    "número de teléfono compartido mediante la url no es válido",
    "número de teléfono compartido a través de la url es inválido",
    "el número de teléfono compartido",
    "no está en whatsapp",
    "no esta en whatsapp",
    "not on whatsapp",
  ];
  return patterns.some((pattern) => bodyText.includes(pattern));
}

async function getPendingDraft() {
  const stored = await chrome.storage.local.get([PENDING_DRAFT_KEY]);
  return stored?.[PENDING_DRAFT_KEY] ?? null;
}

async function clearPendingDraft() {
  awaitingChatNotified = false;
  await chrome.storage.local.remove([PENDING_DRAFT_KEY]);
}

function startObserver() {
  if (observer) return;
  observer = new MutationObserver(() => {
    void applyPendingDraft();
  });
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
  });
}

function stopObserver() {
  if (!observer) return;
  observer.disconnect();
  observer = null;
}

async function notifyBackground(payload) {
  try {
    await chrome.runtime.sendMessage(payload);
  } catch {
    // Ignore background notification failures.
  }
}

async function applyPendingDraft() {
  if (applyingDraft) return { ok: true, applied: false };
  applyingDraft = true;
  try {
    const pending = await getPendingDraft();
    if (!pending?.draftText) return { ok: false, applied: false };

    const composer = findComposer(pending.selectorPack);
  if (!composer) {
    startObserver();
    if (!awaitingChatNotified) {
      awaitingChatNotified = true;
      await notifyBackground({
        type: "RECALC_WHATSAPP_DRAFT_STATUS",
        appBaseUrl: pending.appBaseUrl ?? null,
        extensionSessionToken: pending.extensionSessionToken ?? null,
        runId: pending.runId ?? null,
        eventType: "whatsapp_draft_waiting",
        message:
          "WhatsApp está abierto pero todavía no hay un chat activo. Abre un chat para insertar el borrador.",
        metaJson: {
          source: "content_script",
        },
      });
    }
      return { ok: true, applied: false };
    }

    const applied = fillComposer(composer, pending.draftText);
    if (!applied) {
      return { ok: false, applied: false };
    }

    stopObserver();
    await clearPendingDraft();
    await notifyBackground({
      type: "RECALC_WHATSAPP_DRAFT_STATUS",
      appBaseUrl: pending.appBaseUrl ?? null,
      extensionSessionToken: pending.extensionSessionToken ?? null,
      runId: pending.runId ?? null,
      eventType: "whatsapp_draft_applied",
      message: "El borrador quedó pegado una sola vez en el composer de WhatsApp Web.",
      metaJson: {
        source: "content_script",
      },
    });
    return { ok: true, applied: true };
  } finally {
    applyingDraft = false;
  }
}

async function automateRecipient(payload) {
  const recipient = payload?.recipient ?? null;
  const selectorPack = payload?.selectorPack ?? null;
  if (!recipient?.id) {
    return { ok: false, error: "No llegó un destinatario válido para automatizar." };
  }

  const readyState = await waitFor(() => {
    if (detectInvalidPhoneMessage()) return { invalid: true };
    const composer = findComposer(selectorPack);
    const attachButton = findAttachButton(selectorPack);
    const ready = composer || attachButton || findConversationReady(selectorPack);
    if (!ready) return null;
    if (!composer && !attachButton) return null;
    return { invalid: false, ready };
  }, 15000, 350);

  if (readyState?.invalid) {
    return { ok: false, error: "WhatsApp marcó el número como inválido o no disponible." };
  }

  if (!readyState?.ready) {
    return { ok: false, error: "No fue posible preparar el chat de WhatsApp Web." };
  }

  if (recipient.mediaDownloadUrl) {
    await attachMedia(selectorPack, recipient.mediaDownloadUrl, payload?.extensionSessionToken ?? null);
    const captionComposer = await waitFor(() => findCaptionComposer(selectorPack), 8000, 250);
    let captionApplied = false;
    if (captionComposer && recipient.resolvedMessage) {
      for (let attempt = 0; attempt < 3; attempt += 1) {
        captionApplied = fillComposer(captionComposer, recipient.resolvedMessage);
        await wait(450);
        if (captionApplied && readComposerText(captionComposer) === recipient.resolvedMessage) {
          break;
        }
        captionApplied = false;
        await wait(250);
      }
    }

    const sentMedia = clickSend(selectorPack);
    if (!sentMedia) {
      return { ok: false, error: "No fue posible enviar el adjunto en WhatsApp Web." };
    }

    if ((!captionComposer || !captionApplied) && recipient.resolvedMessage) {
      console.warn(
        "[ReCalc][WA] La imagen fue enviada, pero no se confirmó el caption. Se omite fallback de texto para evitar duplicados.",
      );
    }

    return { ok: true, messageDelayMs: recipient.messageDelayMs ?? 4000 };
  }

  if (!recipient.resolvedMessage) {
    return { ok: false, error: "La campaña no tiene contenido para enviar." };
  }

  const composer = await waitFor(() => findComposer(selectorPack), 15000, 350);
  if (!composer) {
    if (detectInvalidPhoneMessage()) {
      return { ok: false, error: "WhatsApp marcó el número como inválido o no disponible." };
    }
    return { ok: false, error: "No fue posible encontrar el composer de WhatsApp Web." };
  }

  if (!fillComposer(composer, recipient.resolvedMessage || "")) {
    return { ok: false, error: "No fue posible escribir el template en el composer." };
  }

  await wait(250);
  if (!clickSend(selectorPack)) {
    return { ok: false, error: "No fue posible pulsar el botón de enviar." };
  }

  return { ok: true, messageDelayMs: recipient.messageDelayMs ?? 4000 };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "RECALC_APPLY_WHATSAPP_DRAFT") {
    void applyPendingDraft().then((result) => sendResponse(result));
    return true;
  }

  if (message?.type === "RECALC_AUTOMATION_SEND_RECIPIENT") {
    void automateRecipient(message)
      .then((result) => sendResponse(result))
      .catch((error) => {
        sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Falló la automatización del destinatario.",
        });
      });
    return true;
  }

  return undefined;
});

void applyPendingDraft();
